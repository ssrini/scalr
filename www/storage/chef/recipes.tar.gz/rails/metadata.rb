maintainer       "Scalr Inc."
maintainer_email "packages@scalr.net"
license          "All rights reserved"
description      "Installs/Configures Ruby on Rails to work with apache and passenger"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.0.1"
depends          "apache2"
