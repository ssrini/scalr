arch = node[:kernel][:machine]  =~ /x86_64/ ? "x86_64" : "i386"
platform_version = node[:platform_version].to_i

case node[:platform]
when "redhat"
	repo_package_url = "http://yum.pgrpms.org/9.0/redhat/rhel-#{platform_version}-#{arch}/pgdg-redhat90-9.0-5.noarch.rpm"
when "centos"
	repo_package_url = "http://yum.pgrpms.org/9.0/redhat/rhel-#{platform_version}-#{arch}/pgdg-centos90-9.0-5.noarch.rpm"
end

remote_file "/tmp/pgdg-9.rpm" do
	source repo_package_url
end

rpm_package "/tmp/pgdg-9.rpm"

=begin
ruby_block "Exclude postgres from base" do
  block do
    case node.platform
    when "redhat"
     repocfg_paths = ["/etc/yum/pluginconf.d/rhnplugin.conf"]
     sections = ["main"]
    when "centos"
     repocfg_paths = ["/etc/yum.repos.d/CentOS-Base.repo"]
     sections = ["base", "updates"]
    when "fedora"
      repocfg_paths = ["/etc/yum.repos.d/fedora.repo", "/etc/yum.repos.d/fedora-updates.repo"]
      sections = ["fedora"]
    end
    
    regexp = Regexp.new("(\\[(" + sections.join("|") + ")\\][^\\[]*)")
    
    for cfg in repocfg_paths
      if not FileTest.exists?(cfg)
	next
      end
      repo =  File.open(cfg, 'r').read
      repo.gsub!(regexp, "\\1exclude=postgresql*\n")
      File.open(cfg, 'w') {|f| f.write(repo)}
    end
  end
  action :create
end
=end


package "postgresql90"
package "postgresql90-server"
package "postgresql90-devel"


execute "service postgresql-9.0 initdb"

service "postgresql" do
  action [:disable, :stop]
end

execute "sed -i \"s/.*listen_addresses.*/listen_addresses = '*'/g\" /var/lib/pgsql/9.0/data/postgresql.conf"