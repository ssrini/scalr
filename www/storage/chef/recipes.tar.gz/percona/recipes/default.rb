package "mysql-server" do
  action :purge
end

case node[:platform]
when "ubuntu"
	package "mysql-client" do
	  action :purge
	end

	execute "request percona key" do
	  command "gpg --keyserver subkeys.pgp.net --recv-keys 1C4CBDCDCD2EFD2A"
	  not_if "gpg --list-keys CD2EFD2A"
	end

	execute "install percona key" do
	  command "gpg -a --export CD2EFD2A | apt-key add -"
	  not_if "apt-key list | grep CD2EFD2A"
	end

	execute "apt-get update" do
	  action :nothing
	end

	cookbook_file "/etc/apt/sources.list.d/percona.list" do
	  source "percona.list"
          mode "0644"
	  notifies :run, resources("execute[apt-get update]"), :immediately
	end
	

	package "percona-server-server-5.1" do
	  action :install
	  options "--no-install-recommends"
	end

	package "percona-server-client-5.1"

when "redhat","centos"
	package "mysql" do
	  action :purge
	end

	package "mysql-libs" do
		action :purge
	end

	arch = node[:kernel][:machine]  =~ /x86_64/ ? "x86_64" : "i386"
	
	yum_package "gpg"

	execute "rpm -Uvh --replacepkgs http://www.percona.com/downloads/percona-release/percona-release-0.0-1.#{arch}.rpm"

	yum_package "Percona-Server-server-51" do
			action :install
			flush_cache [:before]
	end

	yum_package "Percona-Server-client-51"
	execute "cp /usr/share/mysql/my-medium.cnf /etc/my.cnf"
end

service "mysql" do
	action [ :disable, :stop ]
end
