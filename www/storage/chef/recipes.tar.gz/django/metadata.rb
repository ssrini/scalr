maintainer       "Scalr Inc."
maintainer_email "packages@scalr.net"
license          "All rights reserved"
description      "Installs/Configures Django framework to work with apache and mod_wsgi"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.0.1"
depends          "apache2"
